"use strict";
(self["webpackChunkloyalty"] = self["webpackChunkloyalty"] || []).push([["resources_js_components_Layouts_img_805_gif"],{

/***/ "./resources/js/components/Layouts/img/805.gif":
/*!*****************************************************!*\
  !*** ./resources/js/components/Layouts/img/805.gif ***!
  \*****************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("/images/805.gif?c17546341f72984da38517fb0d7eef89");

/***/ })

}]);
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = function () {
    return React.createElement("img", { src: './img/loader.gif', width: props.children.width, alt: 'Loading...' });
};
//# sourceMappingURL=Loader.js.map
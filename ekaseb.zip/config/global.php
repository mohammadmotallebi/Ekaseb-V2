<?php

return [
    'active' => env('ACTIVE', 1),
    'deactive' => env('DEACTIVE', 0),
];
?>


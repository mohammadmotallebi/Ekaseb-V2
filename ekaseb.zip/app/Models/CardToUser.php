<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

/**
 * App\Models\CardToUser
 *
 * @method static \Illuminate\Database\Eloquent\Builder|CardToUser newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|CardToUser newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|CardToUser query()
 * @mixin \Eloquent
 */
class CardToUser extends Model
{
    //
}

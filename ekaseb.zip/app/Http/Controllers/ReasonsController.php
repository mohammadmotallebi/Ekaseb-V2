<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ReasonsController extends Controller
{
    //
}

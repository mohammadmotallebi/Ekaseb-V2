import React from "react";
import Menu from "./Layout/Menu";
import Grid from "@mui/material/Unstable_Grid2";
import { styled } from "@mui/material/styles";
import Paper from "@mui/material/Paper";


const App = () => {
    return (
            <React.Fragment>
<Menu/>
            </React.Fragment>
    );
};

export default App;

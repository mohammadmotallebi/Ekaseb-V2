<table class="table table-bordered table-hover table-striped" id="bills">
    <thead>

    <td>@lang('lang.billid')</td>
    <td>@lang('lang.buydate')</td>
    <td>@lang('lang.shop')</td>
    <td>@lang('lang.item')</td>
    <td>@lang('lang.price')</td>
    <td>@lang('lang.count')</td>
    <td>@lang('lang.total')</td>
    <td>@lang('lang.score')</td>
    <td>@lang('lang.credit')</td>

    </thead>
</table>



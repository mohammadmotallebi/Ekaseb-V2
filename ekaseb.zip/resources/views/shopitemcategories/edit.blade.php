<form method="patch" id="ShopItemCategoriesForm" class="was-validated">
    <div class="form-group row">
        <label for="item_category_name" class="col-2 col-form-label">@lang('lang.category')</label>
        <div class="col-8">
            <input id="item_category_name" name="item_category_name" type="text" class="form-control" autocomplete="off"
                   required>
        </div>
    </div>


</form>


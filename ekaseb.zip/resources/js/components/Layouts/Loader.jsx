export default () => {
    return <img src='./img/loader.gif' width={props.children.width} alt='Loading...'/>
}
export const USER_INFO = 'USER_INFO';
export const USER_LOADING = 'USER_LOADING';
export const USER_ERROR = 'USER_ERROR';
